import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faGamepad} from '@fortawesome/free-solid-svg-icons';
import {Link} from "react-router-dom";

function Header() {
    return (
        <header className="header">
            <div className="header__logo">
                <div className="bg-logo">
                    <FontAwesomeIcon icon={faGamepad} className="header__logo--icon"></FontAwesomeIcon>
                </div>
                <span className="header__logo--name">GamingRoom</span>
            </div>
            <nav className="header__nav-links">
                <ul>
                    <li><Link to="/mes-reservations">Mes réservations</Link></li>
                    <li><Link to="/profil">Profil</Link></li>
                </ul>
            </nav>
        </header>
    );
}

export default Header;
