import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCalendarDays, faHouse, faRocket} from '@fortawesome/free-solid-svg-icons';
import {Link} from "react-router-dom";

function Sidebar() {
    return (
        <aside className="sidebar">
            <ul className="sidebar__list">
                <li><Link to="/"><FontAwesomeIcon icon={faHouse} className="sidebar__list--icon"/></Link></li>
                <li><Link to="/reservation"><FontAwesomeIcon icon={faCalendarDays} className="sidebar__list--icon"/></Link></li>
                <li><Link to="/jeux"><FontAwesomeIcon icon={faRocket} className="sidebar__list--icon"/></Link></li>
            </ul>
        </aside>
    );
}

export default Sidebar;
