import bgHome from "../../assets/bg-home.webp"

function Home() {
    return (
        <div className="home" style={{backgroundImage: `url(${bgHome})`}}>
            <h1 className="home__heading">Bienvenue sur GamingRoom</h1>
            <p className="home__text">Trouvez la salle de jeux parfaite pour votre prochain événement en quelques clics !</p>
        </div>
    );
}

export default Home;
