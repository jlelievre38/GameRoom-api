

function Game() {
    return (
        <div className="game">
            <h1 className="game__title">Les Jeux</h1>
        </div>
    );
}

export default Game;
