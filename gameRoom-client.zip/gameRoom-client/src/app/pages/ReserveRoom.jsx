import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faDisplay} from "@fortawesome/free-solid-svg-icons";
import {useEffect, useState} from 'react';

function ReserveRoom() {
    const [rooms, setRooms] = useState([]); // Pour stocker toutes les salles
    const [selectedRoom, setSelectedRoom] = useState(null);
    const url = "http://localhost:8080/test";
    const fetchRooms = () => {
        return fetch(url)
            .then((res) => res.json())
            .then((data) => setRooms(data));
    }

    useEffect(() => {
        fetchRooms();
    }, [])

    const reserveRoom = () => {
        if (selectedRoom) {
            fetch(`${url}/room/${selectedRoom.id}`, { method: 'POST' })
                .then(response => {
                    if(response.ok) {
                        fetchRooms();
                        setSelectedRoom(false);
                    } else {
                        console.error('Erreur lors de la réservation de la salle');
                    }
                });
        }
    };

    const cancelRoom = () => {
        if (selectedRoom) {
            fetch(`${url}/room-cancel/${selectedRoom.id}`, { method: 'POST' })
                .then(response => {
                    if(response.ok) {
                        fetchRooms();
                        setSelectedRoom(true);
                    } else {
                        console.error('Erreur lors de l\'annulation de la salle');
                    }
                });
        }
    };

    return (
        <div className="reserve">
            <h1 className="reserve__heading">Réservation</h1>
            <div className="reserve__container">
                {rooms.map((room) => (
                    <div key={room.id}
                         className={`reserve__container--room ${room.status ? 'available' : 'not-available'} ${selectedRoom && room.id === selectedRoom.id ? 'selected-room' : ''}`}
                         onClick={() => setSelectedRoom(room)}>
                        <FontAwesomeIcon icon={faDisplay} className="reserve__container--icon"/>
                        <span>Salle {room.id}</span>
                        <span>{room.status ? 'Disponible' : 'Non Disponible'}</span>
                    </div>
                ))}
            </div>
            <div className="reserve__btns">
                <button onClick={reserveRoom}>Réserver</button>
                <button onClick={cancelRoom}>Annuler une réservation</button>
            </div>
        </div>
    );
}

export default ReserveRoom;
