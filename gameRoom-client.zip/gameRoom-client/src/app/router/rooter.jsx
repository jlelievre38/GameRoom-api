import {createBrowserRouter} from "react-router-dom";
import Root from "./root.jsx";
import Home from "../pages/Home.jsx";
import ReserveRoom from "../pages/ReserveRoom.jsx";
import Game from "../pages/Game.jsx";

const router = createBrowserRouter([
    {
        path: "/",
        element: <Root/>,
        children: [
            {
                path: "/",
                element: <Home/>,
            },
            {
                path: "/reservation",
                element: <ReserveRoom/>,
            },
            {
                path: "/jeux",
                element: <Game/>,
            },
        ]
    }
]);

export default router;
